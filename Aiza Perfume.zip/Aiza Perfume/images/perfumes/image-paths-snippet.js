// Image paths for the existing AIZA product catalog.
const aizaPerfumeImages = {
  "1": "images/perfumes/oud-royale.jpg",
  "2": "images/perfumes/amber-dusk.jpg",
  "3": "images/perfumes/rose-majestic.jpg",
  "4": "images/perfumes/midnight-musk.jpg",
  "5": "images/perfumes/citrus-bloom.jpg",
  "6": "images/perfumes/velvet-oud.jpg",
  "7": "images/perfumes/jasmine-veil.jpg",
  "8": "images/perfumes/desert-wind.jpg",
  "9": "images/perfumes/ocean-mist.jpg",
  "10": "images/perfumes/sandal-essence.jpg",
  "11": "images/perfumes/royal-sultan.jpg",
  "12": "images/perfumes/golden-mirage.jpg",
  "13": "images/perfumes/rose-elixir.jpg",
  "14": "images/perfumes/black-velvet.jpg",
  "15": "images/perfumes/arabian-nights.jpg",
  "16": "images/perfumes/white-jasmine.jpg",
  "17": "images/perfumes/golden-amber.jpg",
  "18": "images/perfumes/ocean-royale.jpg",
  "19": "images/perfumes/pure-serenity.jpg",
  "20": "images/perfumes/imperial-musk.jpg"
};
products.forEach(product => {
  product.image = product.image || aizaPerfumeImages[String(product.id)];
});
