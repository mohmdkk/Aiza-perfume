const products = [
    { id: 1, name: "Oud Royale",  ar: "عود رويال", category: "oud", price: 320, image: "images/perfumes/oud-royale.jpg", notes: "Rich oud and warm spices.", arNotes: "العود الغني والتوابل الدافئة.", c1: "#a77b45", c2: "#382619"  },
    { id: 2, name: "Amber Dusk", ar: "عنبر الغروب", category: "oriental", price: 280, image: "images/perfumes/amber-dusk.jpg", notes: "Amber, vanilla and musk.", arNotes: "العنبر والفانيليا والمسك.", c1: "#ae6339", c2: "#42251b" },
    { id: 3, name: "Rose Majestic", ar: "الورد الملكي", category: "floral", price: 250, image: "images/perfumes/rose-majestic.jpg", notes: "Rose petals and white musk.", arNotes: "بتلات الورد والمسك الأبيض.", c1: "#b77985", c2: "#492c36" },
    { id: 4, name: "Midnight Musk", ar: "مسك منتصف الليل", category: "woody", price: 290, image: "images/perfumes/midnight-musk.jpg", notes: "Smooth musk and cedarwood.", arNotes: "المسك الناعم وخشب الأرز.", c1: "#69615a", c2: "#211e1b" },
    { id: 5, name: "Citrus Bloom", ar: "زهر الحمضيات", category: "fresh", price: 190, notes: "Citrus, bergamot and neroli.", arNotes: "الحمضيات والبرغموت والنيرولي.", c1: "#d0bc6c", c2: "#66602e", image: "images/perfumes/citrus-bloom.jpg" },
    { id: 6, name: "Velvet Oud", ar: "العود المخملي", category: "oud", price: 350, notes: "Deep oud and saffron.", arNotes: "العود العميق والزعفران.", c1: "#846344", c2: "#241b13", image: "images/perfumes/velvet-oud.jpg" },
    { id: 7, name: "Jasmine Veil", ar: "ستار الياسمين", category: "floral", price: 220, notes: "Jasmine and delicate florals.", arNotes: "الياسمين والأزهار الرقيقة.", c1: "#d0c6a5", c2: "#76704e", image: "images/perfumes/jasmine-veil.jpg" },
    { id: 8, name: "Desert Wind", ar: "نسيم الصحراء", category: "oriental", price: 260, notes: "Spiced woods and cardamom.", arNotes: "الأخشاب المتبلة والهيل.", c1: "#bd9566", c2: "#67503a", image: "images/perfumes/desert-wind.jpg" },
    { id: 9, name: "Ocean Mist", ar: "ضباب المحيط", category: "fresh", price: 180, notes: "Sea breeze and fresh musk.", arNotes: "نسيم البحر والمسك المنعش.", c1: "#78a6a6", c2: "#2b555c", image: "images/perfumes/ocean-mist.jpg" },
    { id: 10,name: "Sandal Essence", ar: "جوهر الصندل", category: "woody", price: 300, notes: "Sandalwood, tonka and amber.", arNotes: "خشب الصندل والتونكا والعنبر.", c1: "#b18c68", c2: "#5c3c2c", image: "images/perfumes/sandal-essence.jpg" },
    { id: 11,name: "Royal Sultan",  arabic: "السلطان الملكي",  category: "oud",  price: 330, image: "images/perfumes/royal-sultan.jpg" },
    { id: 12,name: "Golden Mirage",   arabic: "السراب الذهبي",  category: "oriental",    price: 270, image: "images/perfumes/golden-mirage.jpg" },
    { id: 13,name: "Rose Elixir",   arabic: "إكسير الورد",   category: "floral",   price: 240, image: "images/perfumes/rose-elixir.jpg" },
    { id: 14,name: "Black Velvet",  arabic: "المخمل الأسود",  category: "woody",  price: 310, image: "images/perfumes/black-velvet.jpg" },
    { id: 15,name: "Arabian Nights", arabic: "ليالي عربية", category: "oud", price: 350, image: "images/perfumes/arabian-nights.jpg" },
    { id: 16,name: "White Jasmine",  arabic: "الياسمين الأبيض", category: "floral", price: 210, image: "images/perfumes/white-jasmine.jpg" },
    { id: 17, name: "Golden Amber", arabic: "العنبر الذهبي", category: "oriental", price: 290, image: "images/perfumes/golden-amber.jpg" },
    { id: 18, name: "Ocean Royale", arabic: "المحيط الملكي", category: "fresh", price: 200, image: "images/perfumes/ocean-royale.jpg" },
    { id: 19, name: "Pure Serenity",  arabic: "الصفاء النقي",  category: "fresh",  price: 230, image: "images/perfumes/pure-serenity.jpg" },
    { id: 20, name: "Imperial Musk", arabic: "المسك الإمبراطوري", category: "woody", price: 320, image: "images/perfumes/imperial-musk.jpg" }
  ];

  // Keep older product entries compatible and fill optional display fields.
  const defaultNotes = {
    oud: ["A refined oud fragrance with a warm, lasting character.", "عطر عود راقٍ بطابع دافئ وثابت."],
    oriental: ["Warm amber and spices with an elegant finish.", "عنبر وتوابل دافئة بلمسة أنيقة."],
    floral: ["Soft floral notes with a graceful character.", "نفحات زهرية ناعمة بطابع رقيق."],
    fresh: ["Bright, fresh notes for an easy everyday scent.", "نفحات منعشة ومشرقة للاستخدام اليومي."],
    woody: ["Smooth woods and musk in a balanced blend.", "أخشاب ناعمة ومسك في مزيج متوازن."]
  };
  products.forEach(product => {
    product.ar = product.ar || product.arabic || product.name;
    product.notes = product.notes || (defaultNotes[product.category] || defaultNotes.woody)[0];
    product.arNotes = product.arNotes || (defaultNotes[product.category] || defaultNotes.woody)[1];
    product.c1 = product.c1 || "#a77b45";
    product.c2 = product.c2 || "#382619";
    product.size = product.size || "100 ml";
    product.description = product.description || product.notes;
    product.arDescription = product.arDescription || product.arNotes;
    product.stock = Number.isFinite(product.stock) ? product.stock : 12;
  });
  
  const $ = selector => document.querySelector(selector);
  
  const getLanguage = () => localStorage.getItem("aizaLanguage") || "en";
  
  const money = amount => "QAR " + amount.toLocaleString("en-US");
  
  function getCart() {
    try {
      return JSON.parse(localStorage.getItem("aizaCart") || "{}");
    } catch {
      return {};
    }
  }
  
  function saveCart(cart) {
    localStorage.setItem("aizaCart", JSON.stringify(cart));
    updateCartCount();
  }
  
  function updateCartCount() {
    const count = Object.values(getCart())
      .reduce((sum, quantity) => sum + Number(quantity), 0);
  
    document.querySelectorAll("#cartCount").forEach(el => {
      el.textContent = count;
    });
  }
  
  function bottle(product, large = false) {
    if (product.image) {
      return `<img src="${product.image}" alt="${product.name}"
        style="width:100%;height:100%;object-fit:contain">`;
    }
  
    return `
      <div class="${large ? "hero-bottle" : "mini-bottle"}"
        style="--tone1:${product.c1}">
        <span>AIZA</span>
      </div>
    `;
  }
  
  function productCard(product) {
    const ar = getLanguage() === "ar";
    const name = ar ? product.ar : product.name;
    const detailsText = ar ? "التفاصيل" : "VIEW DETAILS";
    const addText = ar ? "أضف إلى الحقيبة" : "ADD TO BAG";

    return `
      <article class="product-card">
        <a href="product.html?id=${product.id}" class="product-art"
          style="--tone1:${product.c1};--tone2:${product.c2}"
          aria-label="${ar ? "عرض تفاصيل " : "View details for "}${name}">
          ${bottle(product)}
        </a>
        <div class="product-info">
          <span class="product-category">${product.category}</span>
          <h3><a class="product-title-link" href="product.html?id=${product.id}">${name}</a></h3>
          <p class="product-notes">${ar ? product.arNotes : product.notes}</p>
          <p class="product-size">${ar ? "الحجم" : "Size"}: ${product.size}</p>
          <div class="product-bottom">
            <span class="product-price">${money(product.price)}</span>
            <button class="add-button" data-add="${product.id}">${addText}</button>
          </div>
          <a class="product-details-link" href="product.html?id=${product.id}">${detailsText} ↗</a>
        </div>
      </article>
    `;
  }

  function renderFeatured() {
    const container = $("#featuredProducts");
    if (!container) return;
  
    container.innerHTML = products.slice(0, 4)
      .map(productCard).join("");
  }
  
  function renderShop() {
    const container = $("#allProducts");
    if (!container) return;

    const query = ($("#searchInput")?.value || "").trim().toLowerCase();
    const category = $("#categoryFilter")?.value || "all";
    const sort = $("#sortFilter")?.value || "featured";
    const ar = getLanguage() === "ar";

    let filtered = products.filter(product => {
      const name = ar ? product.ar : product.name;
      const notes = ar ? product.arNotes : product.notes;
      return (
        (name.toLowerCase().includes(query) ||
         product.name.toLowerCase().includes(query) ||
         notes.toLowerCase().includes(query) ||
         product.category.toLowerCase().includes(query)) &&
        (category === "all" || product.category === category)
      );
    });

    if (sort === "price-low") filtered.sort((a, b) => a.price - b.price);
    if (sort === "price-high") filtered.sort((a, b) => b.price - a.price);
    if (sort === "name") filtered.sort((a, b) => (ar ? a.ar : a.name).localeCompare(ar ? b.ar : b.name));
    if (sort === "newest") filtered.sort((a, b) => b.id - a.id);

    container.innerHTML = filtered.map(productCard).join("");
    const count = $("#resultCount");
    if (count) count.textContent = ar
      ? `عرض ${filtered.length} من ${products.length} عطرًا`
      : `Showing ${filtered.length} of ${products.length} perfumes`;
    const noResults = $("#noResults");
    if (noResults) {
      noResults.hidden = filtered.length > 0;
      noResults.textContent = ar ? "لم يتم العثور على عطور. جرّب بحثًا آخر." : "No perfumes found. Try another search.";
    }
  }

  function renderProductDetails() {
    const container = $("#productDetails");
    if (!container) return;

    const params = new URLSearchParams(window.location.search);
    const id = Number(params.get("id"));
    const product = products.find(item => item.id === id);
    const ar = getLanguage() === "ar";

    if (!product) {
      container.innerHTML = `<div class="empty-message"><p>${ar ? "لم يتم العثور على هذا العطر." : "This perfume could not be found."}</p><a class="button gold-button" href="shop.html">${ar ? "العودة إلى المتجر" : "Back to shop"}</a></div>`;
      return;
    }

    const name = ar ? product.ar : product.name;
    container.innerHTML = `
      <div class="detail-art" style="--tone1:${product.c1};--tone2:${product.c2}">${bottle(product, true)}</div>
      <div class="detail-copy">
        <p class="eyebrow">${product.category}</p>
        <h1>${name}</h1>
        <p class="detail-price">${money(product.price)}</p>
        <p class="detail-description">${ar ? product.arDescription : product.description}</p>
        <div class="detail-spec"><span>${ar ? "الحجم" : "Bottle size"}</span><strong>${product.size}</strong></div>
        <div class="detail-spec"><span>${ar ? "عائلة العطر" : "Fragrance family"}</span><strong>${product.category}</strong></div>
        <div class="detail-spec"><span>${ar ? "النفحات" : "Fragrance notes"}</span><strong>${ar ? product.arNotes : product.notes}</strong></div>
        <button class="button gold-button detail-add-button" data-add="${product.id}">${ar ? "أضف إلى الحقيبة" : "ADD TO BAG"}</button>
        <p class="detail-note">${ar ? "يمكنك مراجعة طلبك في حقيبة التسوق قبل إتمام الشراء." : "Review your selection in the shopping bag before checkout."}</p>
        <a class="text-link" href="shop.html">← ${ar ? "العودة إلى جميع العطور" : "BACK TO ALL PERFUMES"}</a>
      </div>`;
    document.title = `${name} | AIZA Perfumes`;
  }

  function renderCart() {
    const container = $("#cartItems");
    if (!container) return;
  
    const cart = getCart();
    const items = products.filter(p => Number(cart[p.id]) > 0);
    const ar = getLanguage() === "ar";
  
    if (!items.length) {
      container.innerHTML = `
        <div class="empty-message">
          <p>${ar ? "حقيبتك فارغة." : "Your bag is empty."}</p>
          <a href="shop.html" class="button gold-button">
            ${ar ? "تسوق العطور" : "EXPLORE PERFUMES"}
          </a>
        </div>
      `;
      $("#subtotal").textContent = money(0);
      $("#checkoutButton").style.display = "none";
      return;
    }
  
    container.innerHTML = items.map(product => `
      <article class="cart-item">
        <div class="cart-thumb"
          style="--tone1:${product.c1};--tone2:${product.c2}">
          ${bottle(product)}
        </div>
  
        <div>
          <h3>${ar ? product.ar : product.name}</h3>
          <p>${money(product.price)} ${ar ? "للقطعة" : "each"}</p>
  
          <div class="quantity">
            <button data-qty="${product.id}" data-delta="-1">−</button>
            <span>${cart[product.id]}</span>
            <button data-qty="${product.id}" data-delta="1">+</button>
          </div>
  
          <button class="remove-button" data-remove="${product.id}">
            ${ar ? "إزالة" : "Remove"}
          </button>
        </div>
  
        <strong>${money(product.price * cart[product.id])}</strong>
      </article>
    `).join("");
  
    const subtotal = items.reduce(
      (sum, p) => sum + p.price * cart[p.id], 0
    );
  
    $("#subtotal").textContent = money(subtotal);
    $("#checkoutButton").style.display = "inline-block";
  }
  
  function renderCheckout() {
    const container = $("#checkoutItems");
    if (!container) return;
  
    const cart = getCart();
    const items = products.filter(p => Number(cart[p.id]) > 0);
    const ar = getLanguage() === "ar";
  
    container.innerHTML = items.map(p => `
      <div class="summary-line">
        <span>${ar ? p.ar : p.name} × ${cart[p.id]}</span>
        <strong>${money(p.price * cart[p.id])}</strong>
      </div>
    `).join("");
  
    const subtotal = items.reduce(
      (sum, p) => sum + p.price * cart[p.id], 0
    );
  
    const delivery = subtotal === 0 || subtotal >= 300 ? 0 : 20;
  
    $("#checkoutSubtotal").textContent = money(subtotal);
    $("#deliveryCost").textContent =
      delivery === 0 ? (ar ? "مجاني" : "Free") : money(delivery);
  
    $("#checkoutTotal").textContent = money(subtotal + delivery);
  
    return { items, subtotal, delivery, total: subtotal + delivery };
  }
  
  function addToCart(id) {
    const cart = getCart();
    cart[id] = Number(cart[id] || 0) + 1;
    saveCart(cart);
  
    renderCart();
    renderCheckout();
  
    showToast(getLanguage() === "ar"
      ? "تمت إضافة العطر إلى الحقيبة"
      : "Perfume added to your bag");
  }
  
  function showToast(message) {
    let toast = $("#toast");
  
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "toast";
      toast.className = "toast";
      document.body.appendChild(toast);
    }
  
    toast.textContent = message;
    toast.classList.add("show");
  
    clearTimeout(window.aizaToastTimer);
    window.aizaToastTimer = setTimeout(
      () => toast.classList.remove("show"), 2200
    );
  }
  
  function applyLanguage() {
    const ar = getLanguage() === "ar";
  
    document.documentElement.lang = ar ? "ar" : "en";
    document.documentElement.dir = ar ? "rtl" : "ltr";
  
    document.querySelectorAll("[data-en][data-ar]").forEach(element => {
      element.textContent = ar
        ? element.dataset.ar
        : element.dataset.en;
    });
  
    const languageButton = $("#languageButton");
    if (languageButton) {
      languageButton.textContent = ar ? "English" : "العربية";
    }
  
    const search = $("#searchInput");
    if (search) {
      search.placeholder = ar ? "ابحث عن عطر..." : "Search perfumes...";
    }
  
    const filter = $("#categoryFilter");
    if (filter) {
      const names = ar
        ? {
            all: "جميع الفئات", oud: "العود",
            oriental: "شرقي", floral: "زهري",
            fresh: "منعش", woody: "خشبي"
          }
        : {
            all: "All categories", oud: "Oud",
            oriental: "Oriental", floral: "Floral",
            fresh: "Fresh", woody: "Woody"
          };
  
      [...filter.options].forEach(option => {
        option.textContent = names[option.value] || option.textContent;
      });
    }
  
    renderFeatured();
    renderShop();
    renderProductDetails();
    renderCart();
    renderCheckout();
    updateCartCount();
  }
  
  document.addEventListener("DOMContentLoaded", () => {
    const savedTheme = localStorage.getItem("aizaTheme");
    if (savedTheme === "dark") document.body.classList.add("dark");
  
    const themeButton = $("#themeButton");
  
    function updateThemeButton() {
      if (themeButton) {
        themeButton.textContent =
          document.body.classList.contains("dark") ? "☀" : "☾";
      }
    }
  
    updateThemeButton();
  
    themeButton?.addEventListener("click", () => {
      document.body.classList.toggle("dark");
  
      localStorage.setItem(
        "aizaTheme",
        document.body.classList.contains("dark") ? "dark" : "light"
      );
  
      updateThemeButton();
    });
  
    $("#languageButton")?.addEventListener("click", () => {
      localStorage.setItem(
        "aizaLanguage",
        getLanguage() === "en" ? "ar" : "en"
      );
  
      applyLanguage();
    });
  
    $("#menuButton")?.addEventListener("click", () => {
      $("#navigation")?.classList.toggle("open");
    });
  
    $("#searchInput")?.addEventListener("input", renderShop);
    $("#categoryFilter")?.addEventListener("change", renderShop);
    $("#sortFilter")?.addEventListener("change", renderShop);
  
    document.body.addEventListener("click", event => {
      const addButton = event.target.closest("[data-add]");
      const quantityButton = event.target.closest("[data-qty]");
      const removeButton = event.target.closest("[data-remove]");
  
      if (addButton) {
        addToCart(Number(addButton.dataset.add));
      }
  
      if (quantityButton) {
        const cart = getCart();
        const id = quantityButton.dataset.qty;
  
        cart[id] = Number(cart[id] || 0) +
          Number(quantityButton.dataset.delta);
  
        if (cart[id] <= 0) delete cart[id];
  
        saveCart(cart);
        renderCart();
        renderCheckout();
      }
  
      if (removeButton) {
        const cart = getCart();
        delete cart[removeButton.dataset.remove];
  
        saveCart(cart);
        renderCart();
        renderCheckout();
      }
    });
  
    const year = $("#year");
    if (year) year.textContent = new Date().getFullYear();
  
    // Expose only the catalog/cart helpers needed by the checkout module.
    // Order creation itself is handled by checkout.html using Firebase Auth + Firestore.
    window.AIZAStore = {
      products,
      getCart,
      saveCart,
      renderCheckout,
      getLanguage,
      money
    };

    applyLanguage();
  });